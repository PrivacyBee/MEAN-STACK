import { Component, OnInit } from '@angular/core';
import { HttpService } from '../http.service';
import { ActivatedRoute, Router, Params } from '../../../node_modules/@angular/router'


@Component({
  selector: 'app-edit',
  templateUrl: './edit.component.html',
  styleUrls: ['./edit.component.css']
})
export class EditComponent implements OnInit {
  editAuthor :any;
  oneAuthor: any;
  error: any;
  Error=[];


  constructor(private _httpService: HttpService, 
    private _router: Router,
    private _route:ActivatedRoute) {}

  ngOnInit() {
    this.oneAuthor ={
      name : ""
    }
    this._route.params.subscribe((params:Params)=>{
     
      this.getOneAuthor(params.id);
  });
 
}



  getOneAuthor(id) {
    let obs = this._httpService.getAuthorById(id);
    obs.subscribe(data => {
      console.log("Got our Authors!", data)
      if (data['data']) {
        this.oneAuthor = data['data'];
      }
    })
  }
onSubmitEdit (id) {
    let obs = this._httpService.updateAuthor(this.oneAuthor._id, this.oneAuthor);
    obs.subscribe ( data => {
      if (  data["error"] ) {
        console.log(data);
        console.log(data['message']);
        console.log(data['error']);
        for(var key in data['error'].errors){
          console.log(key)
          console.log( data['error'].errors[key].message)
          this.Error.push(data['error'].errors[key].message)
      
        }
        this.error = data;
      }
      else {
        console.log("Successfully update data to server", data);
        this._router.navigate(["/"]);
      };
    });
  };
  reRouteToHome () {
    this._router.navigate(["/"]);
  };
}
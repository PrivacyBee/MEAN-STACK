import { Component, OnInit, Input } from '@angular/core';
import { HttpService } from "./../http.service";

import {ActivatedRoute, Router,Params } from "@angular/router";

@Component({
  selector: 'app-book',
  templateUrl: './book.component.html',
  styleUrls: ['./book.component.css']
})
export class BookComponent implements OnInit {
  id: String;
  newBook: any;
  
  oneAuthor: any;
  error: any;
  books=[];
  Error= [];
  constructor(private _httpService: HttpService,
    private _router: Router, 
    private _route: ActivatedRoute) { }

  ngOnInit() {
    this.newBook ={
      title : "",
      published: null
    }
    this._route.params.subscribe((params:Params)=>{
     
      this.getOneAuthor(params["id"]);
    });
  }
  
  getOneAuthor(id) {
    let obs = this._httpService.getAuthorById(id);
    obs.subscribe(data => {
      console.log("Got our Authors!", data)
      if (data['data']) {
        this.oneAuthor = data['data'];
        console.log(this.oneAuthor);
      }
    })
  }

  onSubmitBook (id) {
    console.log("am in the onsubmit" );
    let obs = this._httpService.createBook(this.oneAuthor._id, this.newBook);
    obs.subscribe ( data => {
      if (  data["error"] ) {
        console.log(data);
        console.log(data['message']);
        console.log(data['error']);
        for(var key in data['error'].errors){
          console.log(key)
          console.log( data['error'].errors[key].message)
          this.Error.push(data['error'].errors[key].message)
      
        }
        this.error = data;
      }
      else {
        console.log("Successfully create book data to server", data);
      this.getOneAuthor(this.oneAuthor._id);
      };
    });
  };
  reRouteToHome () {
    this._router.navigate(["/"]);
  };
}


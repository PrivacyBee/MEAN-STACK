import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { NewComponent } from './new/new.component';
import { EditComponent } from './edit/edit.component';
import { BookComponent } from './book/book.component';
//import { PageNotFoundComponent } from './pagenotfound/pagenotfound.component';

const routes: Routes = [

  { path: 'new',component: NewComponent  },

  { path: 'book/:id',component: BookComponent  },
  

  // use a colon and parameter name to include a parameter in the url
  { path: 'edit/:id', component: EditComponent },

  { path : '', component : HomeComponent},
 
  
 
  //{ path: '**', component: PageNotFoundComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

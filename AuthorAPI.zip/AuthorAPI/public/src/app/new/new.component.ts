import { Component, OnInit, Input } from '@angular/core';
import { HttpService } from "./../http.service";

import {ActivatedRoute, Router,Params } from "@angular/router";
@Component({
  selector: 'app-new',
  templateUrl: './new.component.html',
  styleUrls: ['./new.component.css']
})
export class NewComponent implements OnInit {
  newAuthor: any;
  error: any;
  Error= [];


  constructor( private _httpService: HttpService,
    private _router: Router, 
    private _route: ActivatedRoute) { }

  ngOnInit() {
    this.newAuthor ={
      name : ""
    }
    this._route.params.subscribe((params: Params) => {
      
  });
}


onSubmit() {
  let obs = this._httpService.createAuthor(this.newAuthor);
  obs.subscribe(data => {
     if (  data["error"] ) {
        console.log(data);
        console.log(data['message']);
        console.log(data['error']);
        for(var key in data['error'].errors){
          console.log(key)
          console.log( data['error'].errors[key].message)
          this.Error.push(data['error'].errors[key].message)
      
        }
        this.error = data;
      }
    else {
      console.log("Successfully added data to server!" + data);
      this._router.navigate(["/movies"]);
    };
  });
}

reRouteToHome() {
  this._router.navigate(["/"]);
};
}

import { Component, OnInit } from '@angular/core';
import { HttpService } from '../http.service';
import { ActivatedRoute, Router, Params } from '../../../node_modules/@angular/router'

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  allAuthors = [];
  books=[];
 



  constructor( private _httpService: HttpService,
    private _router: Router, private _route: ActivatedRoute) { }

  ngOnInit() {
    this.getAuthors();

    this._route.params.subscribe((params: Params) => {
   
  });
}
goHome() {
  this._router.navigate(['/']);
}

  getAuthors() {
    let obs = this._httpService.getAllAuthors();
    obs.subscribe(data => {
      console.log("Got our Authors!", data)
      this.allAuthors = data['data'];

    })

  }

  
  onDelete(id) {
    let observable = this._httpService.deleteAuthor(id);
    observable.subscribe(data => {
      console.log("Successfully deleted!", data);
      this.getAuthors();
    });
  };

}

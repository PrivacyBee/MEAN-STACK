var mongoose = require("mongoose");

const BookSchema = new mongoose.Schema({
    title: {
        type: String,
        required: [true, "Title has to have name"]
    },
    published: {
        type: Date,
        required: [true, "A book must have a publisher"]
     
    },
},
    { timestamps: true });
    const Book = mongoose.model('Book', BookSchema)

var AuthorSchema = new mongoose.Schema({
    name: {
        type: String,
        minlength:  [3,"Author name is too short! Name should be at least 3 character!"],
        required: [true,"Author must have a name"],
       
    },
    books: [BookSchema]
},
{
    timestamps: true
});
mongoose.model("Author", AuthorSchema);
var Author = mongoose.model("Author");

module.exports = Author,Book
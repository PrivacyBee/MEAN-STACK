var mongoose = require("mongoose");
require('../models/authors');
var Author = mongoose.model("Author");
const Book = mongoose.model('Book');
module.exports = {

    showAll: (request, response) => {
        Author.find({}, function (error, data) {
            if (error) {
                console.log(error);
                response.json({
                    message: "Error",
                    error: error
                });
            } else {
                console.log(data);
                response.json({
                    message: "Success",
                    data: data
                });
            };
        });
    },

    showOne: (request, response) => {
        Author.findOne({
            _id: request.params.id
        }, function (error, data) {
            if (error) {
                console.log(error);
                response.json({
                    message: "Error",
                    error: error
                });
            } else {
                console.log(data);
                response.json({
                    message: "Success",
                    data: data
                });
            };
        });
    },


    create: (req, res) => {
        Author.create(req.body, (err, data) => {
            if (err) {
                res.json({
                    error: err
                })
            } else {
                console.log("Checkpoint")

                console.log("Author successfully added to Server!")
                res.json({
                    data: data
                });
            }
        })
    },




    createBook: (req, res) => {

        Book.create(req.body, (err, data) => {
            if (err) {
                res.json({
                    error: err
                })
            } else {
                console.log("Checkpoint")
                Author.findOneAndUpdate({
                    _id: req.params.id
                }, {
                    $push: {
                        books: data
                    }
                }, (err, result) => {
                    if (err) {
                        res.json({
                            error: err
                        })
                    } else {
                        console.log("Book successfully added to Author!")
                        res.json({
                            data: data
                        });
                    }
                })
            }
        })
    },

    update: (req, res) => {

        Author.findOneAndUpdate({
                _id: req.params.id
            }, req.body, {
                runValidators: true
            })
            .then(author => {
                res.json({
                    data: author
                });
            })
            .catch(err => {
                res.json({
                    error: err
                })
            })

    },

    destroy: function (request, response) {
        Author.remove({
                _id: request.params.id
            },
            function (error, data) {
                if (error) {
                    console.log(error);
                    response.json({
                        message: "Error",
                        error: error
                    });
                } else {
                    console.log("Successfully removed from database");
                    response.json({
                        message: "Success",
                        data: data
                    });
                };
            });
    }

};
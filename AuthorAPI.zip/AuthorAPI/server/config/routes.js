const path = require("path");


const authors = require("../controllers/authors");

module.exports = function (app) {

    app.get("/api/authors", function (request, response) {
        authors.showAll(request, response);
    });

    app.get("/api/authors/:id", function (request, response) {
        authors.showOne(request, response);
    });

    app.post("/api/create/authors", function (request, response) {
        authors.create(request, response);
    });

    app.post("/api/create/books/:id", function (request, response) {
        authors.createBook(request, response);
    });

    app.put("/api/authors/update/:id", function (request, response) {
        authors.update(request, response);
    });

    app.delete("/api/authors/destroy/:id", function (request, response) {
        authors.destroy(request, response);
    });

  

};
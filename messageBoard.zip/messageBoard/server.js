const sess = require('express-session')
const express = require('express')
const mongoose = require('mongoose')
const flash = require('express-flash')
const path = require('path')
// initialize app
const app = express()

// usings statements
app.use(express.urlencoded({
    extended: true
}))
app.use(express.static(path.join(__dirname, '/static')))

app.use(flash())

app.use(sess({
    secret: 'keyboardTayo',
    resave: false,
    saveUninitialized: true,
    cookie: {
        maxAge: 60000
    }
}))
mongoose.Promise = global.Promise;
// setting statements
app.set('views', path.join(__dirname, '/views'))
app.set('view engine', 'ejs')
mongoose.connect('mongodb://localhost/message_Board', {
    useNewUrlParser: true
});


const commentSchema = new mongoose.Schema({
    name: {
        type: String,
        required: [true, "Comment has to have name"]
    },
    comment: {
        type: String,
        required: [true, "Can't send a comment without a comment"],
        minLength: [10, "Must have minimum characters of 10"]
    },
},
    { timestamps: true });

const messageSchema = new mongoose.Schema({
    name: {
        type: String,
        required: [true, "Message has to have name"]
    },
    message: {
        type: String,
        required: [true, "Can't send a message without a message"],
        minLength: [10, "Must have minimum characters of 10"]},
        comments: [commentSchema]
},
    { timestamps: true });
    const Comment = mongoose.model('Comment', commentSchema)
    const Message = mongoose.model('Message', messageSchema)







    app.post('/new_message', (req, res) => {
     Message.create(req.body)
    .then(message=> res.redirect('/'))
    .catch(err => {
        console.log("We have an error!", err);
        // adjust the code below as needed to create a flash message with the tag and content you would like
        for (var key in err.errors) {
            req.flash('createmessage', err.errors[key].message);
        }
        res.redirect('/');
    })
})


app.post('/new_comment/:id',(req,res)=>{
    Comment.create(req.body)
    .then(comment => {
        console.log(req.params.id);

        console.log("I am in creating comment!");
        Message.findOneAndUpdate({_id: req.params.id},
            {$push: {comments: comment}})
            .then(result => {
                res.redirect('/');
            })
            .catch(err => {
                console.log(err);
                for (var key in err.errors) {
                    req.flash('updatingMessage', err.errors[key].message);
                }
                res.redirect('/');
            })
        })
    .catch(err => {
        for (var key in err.errors) {
            req.flash('createComment', err.errors[key].message);
        }
        res.redirect('/');
    })
})

app.get('/',(req,res) =>{
    Message.find()
        .then(messages=> res.render('index',{allMessages:messages}))
        .catch(err =>{
            console.log(err);
        })
})


app.listen(8000, function () {
    console.log('Listening on port 8000')
})
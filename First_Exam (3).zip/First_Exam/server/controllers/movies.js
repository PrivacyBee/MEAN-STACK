var mongoose = require("mongoose");
require('../models/Movies');
var Movie = mongoose.model("Movie");
const Review = mongoose.model('Review');
module.exports = {

    showAll: (request, response) => {
        Movie.find({}, function (error, data) {
            if (error) {
                console.log(error);
                response.json({
                    message: "Error",
                    error: error
                });
            } else {
                console.log(data);
                response.json({
                    message: "Success",
                    data: data
                });
            };
        });
    },

    showOne: (request, response) => {
        Movie.findOne({
            _id: request.params.id
        }, function (error, data) {
            if (error) {
                console.log(error);
                response.json({
                    message: "Error",
                    error: error
                });
            } else {
                console.log(data);
                response.json({
                    message: "Success",
                    data: data
                });
            };
        });
    },


    create: (req, res) => {
        Movie.create(req.body, (err, data) => {
            if (err) {
                res.json({
                    error: err
                })
            } else {
                console.log("Checkpoint")

                console.log("Movie successfully added to Server!")
                res.json({
                    data: data
                });
            }
        })
    },




    createReview: (req, res) => {

        Review.create(req.body, (err, data) => {
            if (err) {
                res.json({
                    error: err
                })
            } else {
                console.log("Checkpoint")
                Movie.findOneAndUpdate({
                    _id: req.params.id
                }, {
                    $push: {
                        reviews: data
                    }
                }, (err, result) => {
                    if (err) {
                        res.json({
                            error: err
                        })
                    } else {
                        console.log("Review successfully added to Movie!")
                        res.json({
                            data: data
                        });
                    }
                })
            }
        })
    },

    update: (req, res) => {

        Movie.findOneAndUpdate({
                _id: req.params.id
            }, req.body, {
                runValidators: true
            })
            .then(Movie => {
                res.json({
                    data: Movie
                });
            })
            .catch(err => {
                res.json({
                    error: err
                })
            })

    },

    destroy: function (request, response) {
        Movie.remove({
                _id: request.params.id
            },
            function (error, data) {
                if (error) {
                    console.log(error);
                    response.json({
                        message: "Error",
                        error: error
                    });
                } else {
                    console.log("Successfully removed from database");
                    response.json({
                        message: "Success",
                        data: data
                    });
                };
            });
    },

    destroys: function (request, response) {
        Review.remove({
                _id: request.params.id
            },
            function (error, data) {
                if (error) {
                    console.log(error);
                    response.json({
                        message: "Error",
                        error: error
                    });
                } else {
                    console.log("Successfully removed from database");
                    response.json({
                        message: "Success",
                        data: data
                    });
                };
            });
    }

};
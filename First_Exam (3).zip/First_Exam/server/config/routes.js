const path = require("path");


const movies = require("../controllers/movies");

module.exports = function (app) {

    app.get("/api/movies", function (request, response) {
        movies.showAll(request, response);
    });

    app.get("/api/movies/:id", function (request, response) {
        movies.showOne(request, response);
    });

    app.post("/api/create/movies", function (request, response) {
        movies.create(request, response);
    });

    app.post("/api/movies/reviews/:id", function (request, response) {
        movies.createReview(request, response);
    });

    app.put("/api/movies/update/:id", function (request, response) {
        movies.update(request, response);
    });

    app.delete("/api/movies/destroy/:id", function (request, response) {
        movies.destroy(request, response);
    });

    
    app.delete("/api/review/destroys/:id", function (request, response) {
        movies.destroy(request, response);
    });

  

};
import { Component, OnInit } from '@angular/core';
import { HttpService } from '../http.service';
import { ActivatedRoute, Router, Params } from '../../../node_modules/@angular/router'
@Component({
  selector: 'app-movies',
  templateUrl: './movies.component.html',
  styleUrls: ['./movies.component.css']
})
export class MoviesComponent implements OnInit {
  allMovie = [];

  _shownMovieAverage: any;
  _shownMovie: any;



  constructor( private _httpService: HttpService,
    private _router: Router, private _route: ActivatedRoute) { }

  ngOnInit() {
    this.getMovie();

    this._route.params.subscribe((params: Params) => {
   
  });
}
goHome() {
  this._router.navigate(['/']);
}

  getMovie() {
    let obs = this._httpService.getAllmovies();
    obs.subscribe(data => {
      console.log("Got our Movie!", data)
      this.allMovie = data['data'];
      console.log("shownMovie review count:", this._shownMovie.star.length);
      if(this._shownMovie.star.length == 0){
        this._shownMovieAverage = "N/A";
      }
      else{
        let sum = 0;
        console.log("in else: ", this._shownMovie);
        for (let i = 0; i < this._shownMovie.star.length; i++){
          console.log("stars:", this._shownMovie.star[i].star, "stars");
          sum += this._shownMovie.star[i].star;
        }
        this._shownMovieAverage = (sum/this._shownMovie.star.length).toFixed(1);
      }
    })
  }
  

  

  onDelete(id) {
    let observable = this._httpService.deleteMovie(id);
    observable.subscribe(data => {
      console.log("Successfully deleted!", data);
      this.getMovie();
    });
  };
  
}

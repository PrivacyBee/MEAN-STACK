import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { MoviesComponent } from './movies/movies.component';
import { NewComponent } from './new/new.component';
import { MovieidComponent } from './movieid/movieid.component';
import { ReviewComponent } from './review/review.component';

const routes: Routes = [
  { path: 'movies',component:MoviesComponent  },
  { path: 'movies/new',component: NewComponent  },

  { path: 'movies/reviews/:id',component: ReviewComponent  },
  

  // use a colon and parameter name to include a parameter in the url
 { path: 'movies/:id', component: MovieidComponent },

 { path: '', pathMatch: 'full', redirectTo: '/movies' },
 
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

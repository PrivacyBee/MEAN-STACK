import { Component, OnInit, Input } from '@angular/core';
import { HttpService } from "./../http.service";

import {ActivatedRoute, Router,Params } from "@angular/router";

@Component({
  selector: 'app-review',
  templateUrl: './review.component.html',
  styleUrls: ['./review.component.css']
})
export class ReviewComponent implements OnInit {
  id: String;
  newReview: any;
  
  oneMovie: any;
  error: any;

  Error= [];
  constructor(private _httpService: HttpService,
    private _router: Router, 
    private _route: ActivatedRoute) { }

  ngOnInit() {
    this.newReview ={
      names : "",
      stars: "",
      reviewi:""
    }
    this._route.params.subscribe((params:Params)=>{
     
      this.getOneMovie(params["id"]);
    });
  }
  
  getOneMovie(id) {
    let obs = this._httpService.getMovieById(id);
    obs.subscribe(data => {
      console.log("Got our Movies!", data)
      if (data['data']) {
        this.oneMovie = data['data'];
        console.log(this.oneMovie);
      }
    })
  }

  onSubmitReview (id) {
    console.log("am in the onsubmitReview" );
    let obs = this._httpService.createReview(this.oneMovie._id, this.newReview);
    obs.subscribe ( data => {
      if (  data["error"] ) {
        console.log(data);
        console.log(data['message']);
        console.log(data['error']);
        for(var key in data['error'].errors){
          console.log(key)
          console.log( data['error'].errors[key].message)
          this.Error.push(data['error'].errors[key].message)
      
        }
        this.error = data;
      }
      else {
        console.log("Successfully create Review data to server", data);
        this._router.navigate(["/"]);
      };
    });
  };
  reRouteToHome () {
    this._router.navigate(["/"]);
  };
}
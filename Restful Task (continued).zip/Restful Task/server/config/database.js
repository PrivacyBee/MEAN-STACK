var mongoose = require('mongoose');
var fs = require('fs');
// basic_mongoose DB set up
mongoose.connect('mongodb://localhost/tasks')
var models_path = __dirname + '/../models'

fs.readdirSync(models_path).forEach(function(file) {
	if(file.indexOf('.js') >= 0) {
    	require(models_path + '/' + file);
	}
});
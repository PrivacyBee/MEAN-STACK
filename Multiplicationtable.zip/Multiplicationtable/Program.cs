﻿using System;

namespace Multiplicationtable
{
    class Program
    {
        static void Main(string[] args)
        {
               //MULTIPLICATION TABLE
            int[,] multTable = new int[11, 11];
            for (int i = 1; i < 11; i++)
                {
                for (int j = 1; j < 11; j++)
                {
                    multTable[i,j] = i*j;
                    Console.Write(multTable[i,j]+ " ");
                }
                Console.WriteLine();
                }
       }
    }
}

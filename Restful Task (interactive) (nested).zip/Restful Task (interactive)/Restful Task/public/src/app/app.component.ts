import { Component } from '@angular/core';
import { HttpService } from './http.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent  {
  title = 'public';
  constructor(private _httpService: HttpService) { }

  allTasks;
  oneTask;

  getTasks(){
    let obs = this._httpService.getAllTasks();
    obs.subscribe( data => {
      if(data['results']){
        this.allTasks = data['results'];
      }
    })
  }
  getOneTask(id){
    let obs = this._httpService.getOneTask(id);
    obs.subscribe(data => {
      if(data['results']){
        this.oneTask = data['results'];
      }
    })
  }
  closeOneTask(){
    this.oneTask = null;
  }
}


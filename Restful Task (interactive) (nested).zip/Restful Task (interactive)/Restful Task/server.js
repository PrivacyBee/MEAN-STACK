const express = require('express');
    app = express();
  
   
app.use(express.static( __dirname + '/public/dist/public' ));
app.use(express.static(__dirname + '/static'));
app.use(express.urlencoded({extended:true}));

app.set('view engine','ejs');
app.set('views', __dirname + '/views');
app.use(express.json());

require('./server/config/database');
require('./server/config/routes')(app)



const server = app.listen(8000, function () {
    console.log('Listening on port 8000')
});

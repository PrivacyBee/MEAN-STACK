var path = require("path");

module.exports = function (app) {

    app.all("*", (request, response, next) => {
        console.log("ABC");
        response.sendFile(path.resolve("./../public/dist/index.html"));
    });

};
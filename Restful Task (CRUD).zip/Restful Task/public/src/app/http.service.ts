import { Injectable } from '@angular/core';
import { HttpClient} from '@angular/common/http';



@Injectable({
  providedIn: 'root'
})
export class HttpService {
  
constructor(private _http: HttpClient) {
  }
    getAllTasks(){
      return this._http.get('/api/tasks');
    }
    getOneTask(id){
      return this._http.get(`/api/task/${id}`);
    }

    addTask(newTask){
      return this._http.post("/api/create/task", newTask);
    }
  
    deleteTask(id){
      return this._http.delete(`/api/destroy/task/${id}`);
    }
  
    updateTask(id, editTask){
      return this._http.put(`/api/update/task/${id}`, editTask);
    }
  
 }






  


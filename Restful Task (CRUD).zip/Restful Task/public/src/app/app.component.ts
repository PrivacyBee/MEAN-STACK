import { Component, OnInit } from '@angular/core';
import { HttpService } from './http.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'public';
  oneTask = [];
  newTask: any;
  editTask: any;
  allTasks = [];

  Commentform = false;

  constructor(private _httpService: HttpService) {
  }

  ngOnInit() {
    this.getTasks();

    this.newTask = { title: "", description: "" }

  }



  getTasks() {
    let obs = this._httpService.getAllTasks();
    obs.subscribe(data => {
      console.log("Got our tasks!", data)
      this.allTasks = data['results'];

    })

  }
  getOneTask(id) {
    let obs = this._httpService.getOneTask(id);
    obs.subscribe(data => {
      console.log("Got our tasks!", data)
      if (data['results']) {
        this.oneTask = data['results'];
      }
    })
  }
  closeOneTask() {
    this.oneTask = null;
  }

  onSubmit() {
    let obs = this._httpService.addTask(this.newTask);
    obs.subscribe(data => {
      if (data['results']) {
        this.newTask = data['results'];
      }
    })
    this.newTask = { title: "", description: "" }
  }

  onDelete(id) {
    let observable = this._httpService.deleteTask(id);
    observable.subscribe(data => {
      console.log("Successfully deleted!", data);
      this.getTasks();
    });
  };
  onEdit(id) {
    let observable = this._httpService.getOneTask(id);
    observable.subscribe(data => {
      console.log("Successfully updated!", data);
      this.editTask = data['results'];
    });

  };
  onEditSubmit() {
    let observable = this._httpService.updateTask(this.editTask._id, this.editTask);
    observable.subscribe(data => {
      console.log("Successfully updated!", data);
      this.editTask = null;
      this.getTasks();
      
    });
  }
}


const mongoose = require("mongoose")
require('../models/task');

const Task = mongoose.model("Task");

module.exports = {

    index: (req, res) => {

        Task.find()
            .then(tasks => {
                res.json({
                    results: tasks
                });
            })
            .catch(err => {
                res.json({
                    errors: err.errors
                });
            })

    },

    create: (req, res) => {
        Task.create(req.body)
            .then(task =>
                res.json({
                    results: task
                })
            )
            .catch(err => {
                res.json({
                    errors: err.errors
                })
            })
    },

    show: (req, res) => {
        Task.findOne({
                _id: req.params.id
            })
            .then(task => {
                res.json({
                    results: task
                });
            })
            .catch(err => {
                res.json({
                    errors: err.errors
                })
            })
    },

    update: (req, res) => {

        Task.findOneAndUpdate({
                _id: req.params.id
            }, req.body, {
                runValidators: true
            })
            .then(task => {
                res.json({
                    results: task
                });
            })
            .catch(err => {
                res.json({
                    errors: err.errors
                })
            })

    },
    destroy: (req, res) => {
        Task.remove({
                _id: req.params.id
            })
            .then(result => {
                res.json({
                    results: result
                });
            })
            .catch(err => {
                res.json({
                    errors: err.errors
                })
            })

    }

}
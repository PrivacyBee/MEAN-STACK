const mongoose = require('mongoose')

require('../models/quote');
const Quote = mongoose.model('Quotes');

module.exports = {
        index: function (req, res) {
            // code...
            res.render('index');
        },
        
        
        quotes: function (req, res) {
            Quote.find()
            .then(quotes=> res.render('quotes', {allQuotes: quotes}))
            .catch(err =>{
                console.log(err);
                res.render('quotes');
            })
                        },

        add: function (req, res) {
                            // code...
                            Quote.create(req.body)

                                .then(message => res.redirect('/quotes'))
                                .catch(err => {
                                    for (var key in err.errors) {
                                        req.flash('createquote', err.errors[key].message);
                                       
                                    }
                                    res.redirect('/');
                                })

                        }
                    };
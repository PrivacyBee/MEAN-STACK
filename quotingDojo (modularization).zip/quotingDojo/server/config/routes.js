const quote = require('../controllers/quote');

module.exports = (app)=>{
app.get('/',(req, res) =>quote.index (req, res));

app.get('/quotes',(req, res) =>quote.quotes(req, res));

app.post('/quotes',(req, res) =>quote.add(req, res)) 
}
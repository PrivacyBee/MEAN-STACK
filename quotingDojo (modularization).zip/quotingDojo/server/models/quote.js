const mongoose = require('mongoose');
const QuoteSchema = new mongoose.Schema({

    quote: {
        type: String,
        required: [true, "Quote is required"],
        minlength: [10, "Quote must be longer than 10 characters"]
    },
    author: {
        type: String,
        required: [true,"Author is required"]
    },
}, {
    timestamps: true
})

mongoose.model('Quotes', QuoteSchema);
const express = require('express');
const app = express();




const path = require('path');


app.use(express.urlencoded({
    extended: false
}));

app.use(express.static(path.join(__dirname, './static')));
app.set('views', path.join(__dirname, './views'));
app.set('view engine', 'ejs');


const flash = require('express-flash');
app.use(flash());

session = require("express-session"),
app.use(session({
    secret: 'Tayo',
    resave: false,
    saveUninitialized: true,
    cookie: { maxAge: 60000 }
}))
// default for Promises


require('./server/config/routes.js')(app)

require('./server/config/database.js');



// Setting our Server to Listen on Port: 8000
app.listen(8000, function () {
    console.log("listening on port 8000");
});
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { NewComponent } from './new/new.component';
import { HomeComponent } from './home/home.component';
import { EditComponent } from './edit/edit.component';
import { DetailComponent } from './detail/detail.component';

const routes: Routes = [
  //{ path: 'details',component:DetailComponent  },
  { path: 'pets/new',component: NewComponent  },
  { path: 'pets',component: HomeComponent  },

  { path: 'pets/:id',component: DetailComponent  },
  

  // use a colon and parameter name to include a parameter in the url
 { path: 'pets/edit/:id', component: EditComponent },

 { path: '', pathMatch: 'full', redirectTo: '/pets' },
 
];



@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

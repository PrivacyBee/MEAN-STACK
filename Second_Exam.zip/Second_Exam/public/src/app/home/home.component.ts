import { Component, OnInit } from '@angular/core';
import { HttpService } from '../http.service';
import { ActivatedRoute, Router, Params } from '../../../node_modules/@angular/router'
@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  allpets= [];

 constructor( private _httpService: HttpService,
    private _router: Router, private _route: ActivatedRoute) { }

  ngOnInit() {
    this.getpets();

    this._route.params.subscribe((params: Params) => {
   
  });
}
goHome() {
  this._router.navigate(['/']);
}

  getpets() {
    let obs= this._httpService.getAllpets();
    obs.subscribe(data => {
      this.getpets = data['data'];
    });
  }

  routeTo(route, id){
    this._router.navigate([route, id]);
  }
  }
  

  


  


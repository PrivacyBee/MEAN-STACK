import { Component, OnInit } from '@angular/core';

import { HttpService } from '../http.service';

import { ActivatedRoute, Params, Router } from '@angular/router';

@Component({
  selector: 'app-detail',
  templateUrl: './detail.component.html',
  styleUrls: ['./detail.component.css']
})
export class DetailComponent implements OnInit {
  onePet : any;
allPet=[];




  constructor( private _httpService: HttpService,
    private _router: Router, private _route: ActivatedRoute) { }

  ngOnInit() {
    
    

    this._route.params.subscribe((params: Params) => {
      this.getOnePet(params["id"]);
  });
}
goHome() {
  this._router.navigate(['/']);
}

getOnePet(id) {
  let obs = this._httpService.getPetById(id);
  obs.subscribe(data => {
    console.log("Got our Pets!", data)
    if (data['data']) {
      this.onePet = data['data'];
      console.log(this.onePet);
    }
  })
}

like(){
  this.onePet.likes++;
  let updatePetById = this._httpService.updatePet(this.onePet._id, { likes: this.onePet.likes });
  updatePetById.subscribe(data => {
    this.onePet = data['data'];
    this.onePet.skills = data['data'].skills;
    this.onePet.liked = true;
    console.log(this.onePet);
  });
}

onAdopt(id) {
  let observable = this._httpService.deletePet(id);
  observable.subscribe(data => {
    console.log("Successfully deleted!", data);
    this.getOnePet(id);
  });
};


}

import { Injectable } from '@angular/core'
import { HttpClient } from '@angular/common/http'
import { ActivatedRoute, Router, Params } from '../../node_modules/@angular/router'

@Injectable({
  providedIn: 'root'
})
export class HttpService {

  constructor(
    private _http : HttpClient,
    private _router : Router,
  ) {

  }
  getAllpets(){
    return this._http.get('/api/pets')
  }
  createPet(obj){
    return this._http.post('/api/create/pets',obj)
  }

  deletePet(id){
    return this._http.delete('/api/pets/destroy/'+id)
  }




  updatePet(id, obj){
    return this._http.put('/api/pets/update/'+id, obj)
  }

  getPetById (id){
    return this._http.get('/api/pets/'+id)
  }

  goHome(){
    this._router.navigate(['/'])
  }

  goEdit(id){
    this._router.navigate(['edit/'+id])
  }
}


import { Component, OnInit, Input } from '@angular/core';
import { HttpService } from  './../http.service';

import {ActivatedRoute, Router,Params } from "@angular/router";


@Component({
  selector: 'app-new',
  templateUrl: './new.component.html',
  styleUrls: ['./new.component.css']
})
export class NewComponent implements OnInit {
  title = ' pets';
 
  newPet:any;
  error:any;
  Error=[];

constructor(private _httpService: HttpService,
  private _router: Router, 
  private _route: ActivatedRoute) { }

ngOnInit() {
  this.newPet ={
   petname : "",
    type: "",
    description: "",
    skills: " ",
    likes: " "
   
  }
  this._route.params.subscribe((params:Params)=>{
   
  
  });
}



onSubmitPet () {
  console.log("am in the onsubmitPet" );
  let obs = this._httpService.createPet( this.newPet);
  obs.subscribe ( data => {
    if (  data["error"] ) {
      console.log(data);
      for(var key in data['error'].errors){
        console.log(key)
        this.Error.push(data['error'].errors[key].message)
    
      }
      this.error = data;
    }
    else {
      console.log("Successfully create Pet data to server", data);
      this._router.navigate(["/"]);
    };
  });
};
reRouteToHome () {
  this._router.navigate(["/"]);
};
}
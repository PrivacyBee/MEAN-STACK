import { Component, OnInit } from '@angular/core';
import { HttpService } from '../http.service';
import { ActivatedRoute, Router, Params } from '../../../node_modules/@angular/router'

@Component({
  selector: 'app-edit',
  templateUrl: './edit.component.html',
  styleUrls: ['./edit.component.css']
})
export class EditComponent implements OnInit {
  editPet :any;
  onePet: any;
  error: any;
  Error=[];


  constructor(private _httpService: HttpService, 
    private _router: Router,
    private _route:ActivatedRoute) {}

  ngOnInit() {
    this.onePet ={
      name : ""
    }
    this._route.params.subscribe((params:Params)=>{
     
      this.getOnePet(params.id);
  });
 
}



  getOnePet(id) {
    let obs = this._httpService.getPetById(id);
    obs.subscribe(data => {
      console.log("Got our Pets!", data)
      if (data['data']) {
        this.onePet = data['data'];
      }
    })
  }
onEditSubmitPet(id) {
    let obs = this._httpService.updatePet(this.onePet._id, this.onePet);
    obs.subscribe ( data => {
      if (  data["error"] ) {
        console.log(data);
        
        for(var key in data['error'].errors){
          console.log(key)
        
          this.Error.push(data['error'].errors[key].message)
      
        }
        this.error = data;
      }
      else {
        console.log("Successfully update data to server", data);
        this._router.navigate(["/"]);
      };
    });
  };
  reRouteToHome () {
    this._router.navigate(["/"]);
  };
}
const mongoose = require('mongoose');
require('../models/db_model');
var Pet = mongoose.model("Pet");

module.exports = {
    
    showAll: (request, response) => {
        Pet.find({}, function (error, data) {
            if (error) {
                console.log(error);
                response.json({
                    message: "Error",
                    error: error
                });
            } else {
                console.log(data);
                response.json({
                    message: "Success",
                    data: data
                });
            };
        });
    },

    showOne: (request, response) => {
        Pet.findOne({
            _id: request.params.id
        }, function (error, data) {
            if (error) {
                console.log(error);
                response.json({
                    message: "Error",
                    error: error
                });
            } else {
                console.log(data);
                response.json({
                    message: "Success",
                    data: data
                });
            };
        });
    },






    createpet: (req, res) => {

        Pet.create(req.body, (err, data) => {
            if (err) {
                res.json({
                    error: err
                })
            } else {
                console.log("Checkpoint")
                User.findOneAndUpdate({
                    _id: req.params.id
                }, {
                    $push: {
                        users: data
                    }
                }, (err, result) => {
                    if (err) {
                        res.json({
                            error: err
                        })
                    } else {
                        console.log("User successfully added to Pet!")
                        res.json({
                            data: data
                        });
                    }
                })
            }
        })
    },

    update: (req, res) => {

        Pet.findOneAndUpdate({
                _id: req.params.id
            }, req.body, {
                runValidators: true
            })
            .then(Pet => {
                res.json({
                    data: Pet
                });
            })
            .catch(err => {
                res.json({
                    error: err
                })
            })

    },

    destroy: function (request, response) {
        Pet.remove({
                _id: request.params.id
            },
            function (error, data) {
                if (error) {
                    console.log(error);
                    response.json({
                        message: "Error",
                        error: error
                    });
                } else {
                    console.log("Successfully removed from database");
                    response.json({
                        message: "Success",
                        data: data
                    });
                };
            });
    },

    
}
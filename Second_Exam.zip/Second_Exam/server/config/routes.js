const db_ctrl = require('../controllers/db_controller');

const path = require("path");




module.exports = function (app) {

    app.get("/api/pets", function (request, response) {
        pets.showAll(request, response);
    });

    app.get("/api/pets/:id", function (request, response) {
        pets.showOne(request, response);
    });

    app.post("/api/create/pets", function (request, response) {
        pets.createpet(request, response);
    });


    app.put("/api/pets/update/:id", function (request, response) {
        pets.update(request, response);
    });

    app.delete("/api/pets/destroy/:id", function (request, response) {
        pets.destroy(request, response);
    });

    
  

  

};
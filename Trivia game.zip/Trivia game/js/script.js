$(document).ready(function(){
    var container = document.getElementById("container");
    var general = document.createElement('div');
    general.id="general";
    general.className ="category";
    var h1 = document.createElement('h1');
    h1.innerHTML = "General Knowledge";
    general.appendChild(h1);
    $.get("https://opentdb.com/api.php?amount=10&category=9&difficulty=medium&type=multiple", (data) =>
    {
        console.log(data.results);
        var questions = data.results;

        for(var y of questions){
            var div = document.createElement("div");
            dispatchEvent.className ="box";
            var h3 = document.createElement('h3');
            h3.innerHTML = y.question;
            div.appendChild(h3);

            var answers = y.incorrect_answers;
            answers.push(y.correct_answer);
            shuffle(answers);
            for( var a of answers){
                var p = document.createElement('p');
                p.innerHTML = a;
                div.appendChild(p);
            }
            general.appendChild(div);
        }
        container.appendChild(general);
    })
});

function shuffle(arr){
    for(var i = 0; i < arr.length; i++){
        var idx = Math.floor(Math.random() * arr.length);
        var idx2 = Math.floor(Math.random() * arr.length);

        var temp = arr[idx];
        arr[idx] = arr[idx2];
        arr[idx2] = temp;
    }
}
import { Injectable } from '@angular/core'
import { HttpClient } from '@angular/common/http'
import { ActivatedRoute, Router, Params } from '../../node_modules/@angular/router'

@Injectable({
  providedIn: 'root'
})
export class HttpService {

  constructor(
    private _http : HttpClient,
    private _router : Router,
  ) {

  }
  getAllmovies(){
    return this._http.get('/api/movies')
  }
  createMovie(obj){
    return this._http.post('/api/create/movies',obj)
  }

  createReview(id, obj){
    return this._http.post('/api/movies/reviews/'+id,obj)
  }

  deleteMovie(id){
    return this._http.delete('/api/movies/destroy/'+id)
  }

  deleteReview(id){
    return this._http.delete('/api/review/destroys/'+id)
  }


  updateMovie(id, obj){
    return this._http.put('/api/movies/update/'+id, obj)
  }

  getMovieById (id){
    return this._http.get('/api/movies/'+id)
  }

  goHome(){
    this._router.navigate(['/'])
  }

  goEdit(id){
    this._router.navigate(['edit/'+id])
  }

 

}

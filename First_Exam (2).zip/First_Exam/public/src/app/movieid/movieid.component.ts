import { Component, OnInit } from '@angular/core';
import { HttpService } from '../http.service';
import { ActivatedRoute, Router, Params } from '../../../node_modules/@angular/router'

@Component({
  selector: 'app-movieid',
  templateUrl: './movieid.component.html',
  styleUrls: ['./movieid.component.css']
})
export class MovieidComponent implements OnInit {
  oneMovie : any;
allMovie=[];
  reviews=[];



  constructor( private _httpService: HttpService,
    private _router: Router, private _route: ActivatedRoute) { }

  ngOnInit() {
    
    

    this._route.params.subscribe((params: Params) => {
      this.getOneMovie(params["id"]);
  });
}
goHome() {
  this._router.navigate(['/']);
}

getOneMovie(id) {
  let obs = this._httpService.getMovieById(id);
  obs.subscribe(data => {
    console.log("Got our Movies!", data)
    if (data['data']) {
      this.oneMovie = data['data'];
      console.log(this.oneMovie);
    }
  })
}

getOneReview(id) {
  let obs = this._httpService.getMovieById(id);
  obs.subscribe(data => {
    console.log("Got our Movies!", data)
    if (data['data']) {
      this.oneMovie = data['data'];
      console.log(this.oneMovie);
    }
  })
}
onDelete(id) {
  let observable = this._httpService.deleteReview(id);
  observable.subscribe(data => {
    console.log("Successfully deleted!", data);
    this.getOneReview(id);
  });
};
}

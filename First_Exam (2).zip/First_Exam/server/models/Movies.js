var mongoose = require("mongoose");

const ReviewSchema = new mongoose.Schema({
    names: {
        type: String,
        minlength:  [3," Name is too short! Name should be at least 3 character!"],
        required: [true, "Reviewer has to have name"]
    },
    stars: {
        type: String,
        required: [true, "A Rating must have a star"]
     
    },

    reviewi: {
        type: String,
        required: [true," A movie must have a review"]
    }
},
    { timestamps: true });
    const Review = mongoose.model('Review', ReviewSchema)

var MovieSchema = new mongoose.Schema({
    title: {
        type: String,
        minlength:  [3,"Movie name is too short! Name should be at least 3 character!"],
        required: [true,"Movie must have a title"],
       
    },

    name: {
        type: String,
        minlength:  [3," Name is too short! Name should be at least 3 character!"],
        required: [true, "Title has to have name"]
    },
    star: {
        type: String,
        required: [true, "A Rating must have a star"]
     
    },

    review: {
        type: String,
        required: [true," A movie must have a review"]
    },
    reviews: [ReviewSchema]
},
{
    timestamps: true
});
mongoose.model("Movie", MovieSchema);
var Movie = mongoose.model("Movie");

module.exports = Movie,Review
$(document).ready(function(){
    let url = 'https://api.github.com/users/PrivacyBee'
    $('#btn').click(function(){
        $.get(url, function(res){
            let myname = res.login 
            $('.info').html(myname)
            console.log(myname);
        })
    })
})